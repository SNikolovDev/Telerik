﻿using Cosmetics.Core.Contracts;
using Cosmetics.Helpers;
using Cosmetics.Models;
using System;
using System.Collections.Generic;

using Cosmetics.Models.Enums;

namespace Cosmetics.Commands
{
    public class CreateShampooCommand : BaseCommand
    {
        public const int ExpectedNumberOfArguments = 6;

        public CreateShampooCommand(IList<string> parameters, IRepository repository)
            : base(parameters, repository)
        {
        }

        public override string Execute()
        {
            ValidationHelper.ValidateArgumentsCount(this.CommandParameters, ExpectedNumberOfArguments);

            GenderType gender = GenderType.Men;
            switch (CommandParameters[3])
            {
                case "Men":
                    gender = GenderType.Men;
                    break;
                case "Women":
                    gender = GenderType.Women;
                    break;
                case "Unisex":
                    gender = GenderType.Unisex;
                    break;
                default:
                    break;
            }

            UsageType usage = UsageType.EveryDay;
            switch (CommandParameters[5])
            {
                case "EveryDay":
                    usage = UsageType.EveryDay;
                    break;
                case "Medical":
                    usage = UsageType.Medical;
                    break;
                default:
                    break;
            }


            return CreateShampoo(CommandParameters[0], CommandParameters[1], decimal.Parse(CommandParameters[2]), gender, int.Parse(CommandParameters[4]), usage).ToString();
        }

        private string CreateShampoo(string name, string brand, decimal price, GenderType genderType, int millilitres, UsageType usageType)
        {
            if (this.Repository.ProductExists(name))
            {
                throw new ArgumentException(string.Format($"Shampoo with name {name} already exists!"));
            }

            this.Repository.CreateShampoo(name, brand, price, genderType, millilitres, usageType);

            return $"Shampoo with name {name} was created!";
        }
    }
}
