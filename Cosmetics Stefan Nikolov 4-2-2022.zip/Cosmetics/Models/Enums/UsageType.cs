﻿namespace Cosmetics.Models.Enums
{
    public enum UsageType
    {
        EveryDay,
        Medical
    }
}
