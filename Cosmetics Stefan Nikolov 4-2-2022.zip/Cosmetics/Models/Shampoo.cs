﻿using System.Text;

using Cosmetics.Helpers;
using Cosmetics.Models.Enums;
using Cosmetics.Models.Contracts;

namespace Cosmetics.Models
{
    public class Shampoo : Product, IShampoo
    {
        private int millilitres;

        public Shampoo(string name, string brand, decimal price, GenderType gender, int millilitres, UsageType usage)
            : base(name, brand, price, gender)
        {
            this.Millilitres = millilitres;
            this.Usage = usage;

            this.Millilitres = millilitres;
            this.Usage = usage;
        }

        public int Millilitres
        {
            get => this.millilitres;
            set
            {
                ValidationHelper.ValidateNonNegative(value, nameof(millilitres));
      
                this.millilitres = value;
            }
        }

        public UsageType Usage { get; set; }

        public override string Print()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"#{this.Name} {this.Brand}");
            sb.AppendLine($" #Price: ${this.Price}");
            sb.AppendLine($" #Gender: {this.Gender}");
            sb.AppendLine($" #Milliliters: {this.Millilitres}");
            sb.AppendLine($" #Usage: {this.Usage.ToString()}");

            return sb.ToString().TrimEnd();
        }
    }
}
