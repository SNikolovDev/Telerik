﻿using System.Collections.Generic;

namespace BoardR
{
    public static class Board
    {
        public static List<BoardItem> items = new List<BoardItem>();
    }
}
