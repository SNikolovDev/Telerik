﻿using System;
using System.Collections.Generic;

using Cosmetics.Helpers;
using Cosmetics.Models.Enums;
using Cosmetics.Core.Contracts;

namespace Cosmetics.Commands
{
    public class CreateToothpasteCommand : BaseCommand
    {
        public const int ExpectedNumberOfArguments = 5;

        public CreateToothpasteCommand(IList<string> parameters, IRepository repository)
            : base(parameters, repository)
        {
        }

        public override string Execute()
        {
            ValidationHelper.ValidateArgumentsCount(this.CommandParameters, ExpectedNumberOfArguments);

            GenderType gender = GenderType.Men;
            switch (CommandParameters[3])
            {
                case "Men":
                    gender = GenderType.Men;
                    break;
                case "Women":
                    gender = GenderType.Women;
                    break;
                case "Unisex":
                    gender = GenderType.Unisex;
                    break;
                default:
                    break;
            }

            return CreateToothpaste(CommandParameters[0], CommandParameters[1], decimal.Parse(CommandParameters[2]), 
                gender, CommandParameters[4]);
        }

        private string CreateToothpaste(string name, string brand, decimal price, GenderType genderType, string ingredients)
        {
            if (this.Repository.ProductExists(name))
            {
                throw new ArgumentException(string.Format($"Toothpaste with name {name} already exists!"));
            }

            this.Repository.CreateToothpaste(name, brand, price, genderType, ingredients);

            return $"Toothpaste with name {name} was created!";
        }
    }
}
