﻿using System.Collections.Generic;

using Cosmetics.Helpers;
using Cosmetics.Core.Contracts;
using Cosmetics.Models.Contracts;

namespace Cosmetics.Commands
{
    public class RemoveFromShoppingCartCommand : BaseCommand
    {
        public const int ExpectedNumberOfArguments = 1;

        public RemoveFromShoppingCartCommand(IList<string> parameters, IRepository repository)
            : base(parameters, repository)
        {
        }

        public override string Execute()
        {
            ValidationHelper.ValidateArgumentsCount(this.CommandParameters, ExpectedNumberOfArguments);
            
            string productToRemove = this.CommandParameters[0];

            return RemoveFromShoppingCart(productToRemove);
        }

        private string RemoveFromShoppingCart(string productName)
        {
            IShoppingCart shoppingCart = this.Repository.ShoppingCart;
            IProduct product = this.Repository.FindProductByName(productName);

            shoppingCart.RemoveProduct(product);

            return $"Product {productName} was removed from the shopping cart!";
        }
    }
}
