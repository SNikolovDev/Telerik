﻿using System;
using System.Text;

using Cosmetics.Models.Enums;
using Cosmetics.Models.Contracts;

namespace Cosmetics.Models
{
    public class Toothpaste : Product, IToothpaste
    {
        private string ingredients;

        public Toothpaste(string name, string brand, decimal price, GenderType gender, string ingredients)
            : base(name, brand, price, gender)
        {
            this.Ingredients = ingredients;
        }

        public string Ingredients
        {
            get => this.ingredients;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException("Value can not be null");
                }

                this.ingredients = value;
            }
        }

        public override string Print()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"#{this.Name} {this.Brand}");
            sb.AppendLine($" #Price: ${this.Price}");
            sb.AppendLine($" #Gender: {this.Gender}");
            sb.AppendLine($" #Ingredients: {this.Ingredients.ToString()}");

            return sb.ToString().TrimEnd();
        }
    }
}
