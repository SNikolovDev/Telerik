﻿using System.Collections.Generic;

using Cosmetics.Models.Enums;
using Cosmetics.Models.Contracts;

namespace Cosmetics.Core.Contracts
{
    public interface IRepository
    {
        IShoppingCart ShoppingCart { get; }

        IList<ICategory> Categories { get; }

        IList<IProduct> Products { get; }

        IProduct FindProductByName(string productName);

        ICategory FindCategoryByName(string categoryName);

        void CreateCategory(string categoryToAdd);

        IShampoo CreateShampoo(string name, string brand, decimal price, GenderType genderType, int millilitres, UsageType usageType);

        IToothpaste CreateToothpaste(string name, string brand, decimal price, GenderType genderType, string ingredients);
       
        ICream CreateCream(string name, string brand, decimal price, GenderType genderType, Scent scent);

        bool CategoryExists(string categoryName);

        bool ProductExists(string productName);
    }
}
