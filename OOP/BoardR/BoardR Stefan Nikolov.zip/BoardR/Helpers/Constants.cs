﻿namespace BoardR
{
    public static class Constants
    {
        public const int NAME_MIN_VALUE = 5;
        public const int NAME_MAX_VALUE = 30;
    }
}
