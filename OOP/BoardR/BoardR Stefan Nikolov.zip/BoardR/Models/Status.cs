﻿namespace BoardR
{
    public enum Status
    {
        Open, Todo, InProgress, Done, Verified
    }
}
