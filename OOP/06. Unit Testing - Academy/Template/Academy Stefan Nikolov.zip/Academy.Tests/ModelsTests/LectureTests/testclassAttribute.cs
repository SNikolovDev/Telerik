﻿using System;

namespace Academy.Tests.ModelsTests.LectureTests
{
    internal class testclassAttribute : Attribute
    {
    }
}