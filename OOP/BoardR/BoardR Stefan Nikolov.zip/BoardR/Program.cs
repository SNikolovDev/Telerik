﻿using System;

namespace BoardR
{
    class Program
    {
        static void Main(string[] args)
        {
          
        }
    }
}
