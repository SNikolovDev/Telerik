﻿namespace Cosmetics.Models.Enums
{
    public enum Scent
    {
        lavender,
        vanilla,
        rose
    }
}
