﻿using System.Text;

using Cosmetics.Helpers;
using Cosmetics.Models.Enums;
using Cosmetics.Models.Contracts;

namespace Cosmetics.Models
{
    public class Cream : Product, ICream
    {
        private string name;
        private string brand;
        private decimal price;
       
        public new const int NameMinLength = 3;
        public new const int NameMaxLength = 15;
        public new const int BrandMinLength = 3;
        public new const int BrandMaxLength = 15;

        public Cream(string name, string brand, decimal price, GenderType gender, Scent scent)
            : base(price, gender)
        {
            this.Name = name;
            this.Brand = brand;
            this.Price = price;
            this.Scent = scent;
        }

        public override string Name
        {
            get => this.name;
            set
            {
                ValidationHelper.ValidateStringLength(value, NameMinLength, NameMaxLength);

                this.name = value;
            }
        }

        public override string Brand
        {
            get => this.brand;
            set
            {
                ValidationHelper.ValidateStringLength(value, BrandMinLength, BrandMaxLength);

                this.brand = value;
            }
        }

        public new decimal Price
        {
            get => this.price;
            set
            {
                ValidationHelper.ValidateGreaterThanZero(value, nameof(price));

                this.price = value;
            }
        }

        public Scent  Scent { get; set; }

        public override string Print()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"#{this.Name} {this.Brand}");
            sb.AppendLine($" #Price: ${this.Price}");
            sb.AppendLine($" #Gender: {this.Gender}");
            sb.AppendLine($" #Scent: {this.Scent}");

            return sb.ToString().TrimEnd();
        }
    }
}
