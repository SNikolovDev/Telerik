﻿namespace BoardR.Loggers
{
    public interface ILogger
    {
        public void Log(string value);
    }
}
