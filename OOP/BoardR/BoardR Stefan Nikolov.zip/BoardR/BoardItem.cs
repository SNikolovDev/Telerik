﻿using System;

namespace BoardR
{
    public class BoardItem
    {
        //title - describes what this item is about;
        //dueDate - by when it should be finished;
        //status - describes the state of this item - being worked on, being completed, etc..;

        public string title;
        public DateTime dueDate;
        public Status status;

        public BoardItem(string title, DateTime dueDate)
        {
            if (title == null)
            {
                throw new NullReferenceException();
            }

            else if (title.Length < 5 || title.Length > 30 || title == string.Empty)
            {
                throw new Exception("Title length should be between 5 and 30 characters!");
            }

            if (dueDate <= DateTime.Now)
            {
                throw new Exception("Time and date must be in the future!");
            }

            this.title = title; // non-empty, at least several characters -> [5-30];
            this.dueDate = dueDate; // must be in the future;
            this.status = Status.Open;// must be Open on initializaton;
        }

      
        public void RevertStatus()
        {
            if (this.status == Status.Open)
            {
                return;
            }

            this.status--;
        }

        public void AdvanceStatus()
        {
            if (this.status == Status.Verified)
            {
                return;
            }

            status++;
        }

        public string ViewInfo()
        {
            return $"'{this.title}', [{this.status}|{dueDate:dd-MM-yyyy}]";
        }
    }
}
