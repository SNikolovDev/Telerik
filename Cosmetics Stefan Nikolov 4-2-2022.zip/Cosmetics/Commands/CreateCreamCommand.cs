﻿using System;
using System.Collections.Generic;

using Cosmetics.Helpers;
using Cosmetics.Models.Enums;
using Cosmetics.Core.Contracts;

namespace Cosmetics.Commands
{
    public class CreateCreamCommand : BaseCommand
    {
        public const int ExpectedNumberOfArguments = 5;

        public CreateCreamCommand(IList<string> parameters, IRepository repository)
            : base(parameters, repository)
        {
        }

        public override string Execute()
        {
            ValidationHelper.ValidateArgumentsCount(this.CommandParameters, ExpectedNumberOfArguments);

            GenderType gender = GenderType.Men;
            switch (CommandParameters[3])
            {
                case "Men":
                    gender = GenderType.Men;
                    break;
                case "Women":
                    gender = GenderType.Women;
                    break;
                case "Unisex":
                    gender = GenderType.Unisex;
                    break;
                default:
                    break;
            }

            Scent scent = Scent.lavender;
            switch (CommandParameters[3])
            {
                case "lavener":
                    scent = Scent.lavender;
                    break;
                case "rose":
                    scent = Scent.rose;
                    break;
                case "vanilla":
                    scent = Scent.vanilla;
                    break;
                default:
                    break;
            }


            return CreateCream(CommandParameters[0], CommandParameters[1], decimal.Parse(CommandParameters[2]),
                gender, scent);
        }

        private string CreateCream(string name, string brand, decimal price, GenderType genderType, Scent scent)
        {
            if (this.Repository.ProductExists(name))
            {
                throw new ArgumentException(string.Format($"Cream with name {name} already exists!"));
            }

            this.Repository.CreateCream(name, brand, price, genderType, scent);

            return $"Cream with name {name} was created!";
        }
    }
}