﻿using Cosmetics.Models.Enums;

namespace Cosmetics.Models.Contracts
{
    public interface ICream
    {
        public Scent Scent { get; }
    }
}
