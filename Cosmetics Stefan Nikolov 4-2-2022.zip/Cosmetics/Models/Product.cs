﻿using Cosmetics.Helpers;
using Cosmetics.Models.Enums;
using Cosmetics.Models.Contracts;

namespace Cosmetics.Models
{
    public abstract class Product : IProduct
    {
        private string name;
        private string brand;
        private decimal price;

        public const int NameMinLength = 3;
        public const int NameMaxLength = 10;
        public const int BrandMinLength = 2;
        public const int BrandMaxLength = 10;

        protected Product(decimal price, GenderType gender)
        {
            this.price = price;
            Gender = gender;
        }

        protected Product(string name, string brand, decimal price, GenderType genderType)
        {
            this.Name = name;
            this.Brand = brand;
            this.Price = price;
            this.Gender = genderType;
        }


        public virtual string Name
        {
            get => this.name;
            set
            {
                ValidationHelper.ValidateStringLength(value, NameMinLength, NameMaxLength);

                this.name = value;
            }
        }

        public virtual string Brand
        {
            get => this.brand;
            set
            {
                ValidationHelper.ValidateStringLength(value, BrandMinLength, BrandMaxLength);

                this.brand = value;
            }
        }

        public decimal Price
        {
            get => this.price;
            set
            {
                ValidationHelper.ValidateNonNegative(value, nameof(price));

                this.price = value;
            }
        }

        public GenderType Gender { get; set; }

        public abstract string Print();
    }
}